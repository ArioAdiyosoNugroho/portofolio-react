import { useRef } from 'react';
import { useScroll, useTransform, motion } from 'framer-motion';
import { Link } from 'react-router-dom';

// ── ZoomParallax core ──────────────────────────────────────────────────────────
function ZoomParallax({ images }) {
  const container = useRef(null);
  const { scrollYProgress } = useScroll({
    target: container,
    offset: ['start start', 'end end'],
  });

  const scale4 = useTransform(scrollYProgress, [0, 1], [1, 4]);
  const scale5 = useTransform(scrollYProgress, [0, 1], [1, 5]);
  const scale6 = useTransform(scrollYProgress, [0, 1], [1, 6]);
  const scale8 = useTransform(scrollYProgress, [0, 1], [1, 8]);
  const scale9 = useTransform(scrollYProgress, [0, 1], [1, 9]);

  const scales = [scale4, scale5, scale6, scale5, scale6, scale8, scale9];

  return (
    <div ref={container} className="relative h-[300vh]">
      <div className="sticky top-0 h-screen overflow-hidden">
        {images.map(({ src, alt }, index) => {
          const scale = scales[index % scales.length];
          return (
            <motion.div
              key={index}
              style={{ scale }}
              className={[
                'absolute top-0 flex h-full w-full items-center justify-center',
                index === 1 ? '[&>div]:!-top-[30vh] [&>div]:!left-[5vw] [&>div]:!h-[30vh] [&>div]:!w-[35vw]' : '',
                index === 2 ? '[&>div]:!-top-[10vh] [&>div]:!-left-[25vw] [&>div]:!h-[45vh] [&>div]:!w-[20vw]' : '',
                index === 3 ? '[&>div]:!left-[27.5vw] [&>div]:!h-[25vh] [&>div]:!w-[25vw]' : '',
                index === 4 ? '[&>div]:!top-[27.5vh] [&>div]:!left-[5vw] [&>div]:!h-[25vh] [&>div]:!w-[20vw]' : '',
                index === 5 ? '[&>div]:!top-[27.5vh] [&>div]:!-left-[22.5vw] [&>div]:!h-[25vh] [&>div]:!w-[30vw]' : '',
                index === 6 ? '[&>div]:!top-[22.5vh] [&>div]:!left-[25vw] [&>div]:!h-[15vh] [&>div]:!w-[15vw]' : '',
              ].join(' ')}
            >
              <div className="relative h-[25vh] w-[25vw]">
                <img
                  src={src}
                  alt={alt || `Parallax image ${index + 1}`}
                  className="h-full w-full object-cover"
                />
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}

// ── Portfolio images (7 max) ───────────────────────────────────────────────────
const portfolioImages = [
  { src: '/assets/img/web/web-alhadi.png',      alt: 'Alhadi' },
  { src: '/assets/img/web/web-gf2.png',          alt: 'GF2 Racing' },
  { src: '/assets/img/web/web-resik.png',        alt: 'Resik.id' },
  { src: '/assets/img/web/web-ads.png',          alt: 'ADS Motor Racing' },
  { src: '/assets/img/web/web-hutan-kita.png',    alt: 'Hutan Kita' },
  { src: '/assets/img/web/perpustakaan.png',     alt: 'Perpustakaan Digital' },
  { src: '/assets/img/web/web-putri-jaya.jpeg',  alt: 'Zalfa Jaya' },
];

// ── Section header ─────────────────────────────────────────────────────────────
function PortfolioHeader() {
  return (
    <div className="flex flex-col items-center justify-center py-24 bg-gray-950 text-white text-center px-6">
      <span className="inline-block border border-white/20 bg-white/10 rounded-full px-4 py-1.5 text-xs font-semibold tracking-widest uppercase mb-6">
        Portfolio
      </span>
      <h2 className="font-display text-4xl md:text-6xl font-extrabold leading-tight tracking-tight max-w-3xl">
        Jelajahi proyek-proyek<br className="hidden md:block" /> terbaik kami
      </h2>
    </div>
  );
}

// ── Portfolio footer CTA ───────────────────────────────────────────────────────
// ── Portfolio footer CTA (Revisi agar tidak terlihat kosong) ───────────────────
function PortfolioFooter() {
  return (
    <div className="relative flex flex-col items-center justify-center py-32 bg-gray-950 text-white text-center px-6 overflow-hidden">
      
      {/* Dekorasi Visual: Gradient Glow agar tidak terlalu "flat" hitam */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[300px] bg-blue-500/10 blur-[120px] rounded-full pointer-events-none" />

      <div className="relative z-10 max-w-2xl">
        <h3 className="text-2xl md:text-3xl font-bold mb-4 tracking-tight">
          Punya ide luar biasa? <br/> Mari kita wujudkan bersama.
        </h3>
        <p className="text-gray-400 mb-10 text-sm md:text-base leading-relaxed">
          Setiap proyek adalah cerita baru. Kami menggabungkan strategi data 
          dengan kreativitas komunitas untuk hasil yang berdampak nyata.
        </p>

        <Link
          to="/portfolio"
          className="inline-flex items-center bg-white text-gray-900 rounded-full pl-6 pr-2 py-2 gap-4 hover:bg-gray-100 hover:shadow-[0_0_20px_rgba(255,255,255,0.3)] hover:-translate-y-1 transition-all duration-300 group"
        >
          <span className="text-sm font-bold tracking-wide">Lihat Semua Proyek</span>
          <span className="w-10 h-10 rounded-full bg-gray-900 text-white flex items-center justify-center shrink-0 group-hover:rotate-[-45deg] transition-transform duration-300">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </span>
        </Link>
      </div>
    </div>
  );
}
// ── Main export ────────────────────────────────────────────────────────────────
export default function Portfolio() {
  return (
    <section id="portfolio" className="bg-gray-950">
      <PortfolioHeader />
      <ZoomParallax images={portfolioImages} />
      <PortfolioFooter />
    </section>
  );
}